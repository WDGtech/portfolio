from scapy.all import ARP, Ether, srp
import argparse

def scan_network(ip_range):
    """
    Functie om apparaten in een opgegeven IP-bereik te scannen.
    :param ip_range: Het IP-bereik dat gescand moet worden.
    """
    # Maak een ARP-verzoek
    arp_request = ARP(pdst=ip_range)
    broadcast = Ether(dst="ff:ff:ff:ff:ff:ff")
    arp_request_broadcast = broadcast / arp_request

    # Stuur het verzoek en ontvang antwoorden
    print(f"Scanning netwerk: {ip_range}...")
    answered_list = srp(arp_request_broadcast, timeout=2, verbose=False)[0]

    # Verwerk de antwoorden
    devices = []
    for sent, received in answered_list:
        devices.append({'ip': received.psrc, 'mac': received.hwsrc})

    return devices

def display_results(devices):
    """
    Functie om gescande resultaten weer te geven.
    :param devices: Lijst van gedetecteerde apparaten.
    """
    print("\nGevonden apparaten:")
    print("IP-adres" + " " * 20 + "MAC-adres")
    print("-" * 50)
    for device in devices:
        print(f"{device['ip']:<30} {device['mac']}")

if __name__ == "__main__":
    # Argumentparser instellen
    parser = argparse.ArgumentParser(description="Netwerk Scanner")
    parser.add_argument("ip_range", help="Het IP-bereik dat gescand moet worden (bijv. 192.168.1.0/24).")
    args = parser.parse_args()

    # Netwerk scannen
    scanned_devices = scan_network(args.ip_range)

    # Resultaten weergeven
    display_results(scanned_devices)
